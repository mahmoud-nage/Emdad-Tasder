<?php

namespace App\Http\Controllers\API\Web;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SubCategoryController extends Controller
{
    //
}
